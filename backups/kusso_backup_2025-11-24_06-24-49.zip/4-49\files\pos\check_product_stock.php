<?php
header('Content-Type: application/json');
include('../includes/config.php');

$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
$size = isset($_GET['size']) ? $_GET['size'] : '';

if (!$product_id) {
    echo json_encode(['success' => false, 'error' => 'No product ID provided.']);
    exit;
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get all required ingredients and their required quantity for this product and size
    $stmt = $pdo->prepare("SELECT pi.ingredient_id, pi.quantity_required, i.name, i.quantity AS stock, i.unit FROM product_ingredients pi JOIN ingredients i ON pi.ingredient_id = i.id WHERE pi.product_id = :product_id");
    $stmt->execute(['product_id' => $product_id]);
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $insufficient = [];
    foreach ($ingredients as $row) {
        $required = $row['quantity_required'];
        if ($row['stock'] < $required) {
            $insufficient[] = [
                'name' => $row['name'],
                'required' => $required,
                'stock' => $row['stock'],
                'unit' => $row['unit']
            ];
        }
    }
    // Always return the full ingredient list for frontend low stock check
    if (count($insufficient) > 0) {
        echo json_encode(['success' => false, 'insufficient' => $insufficient, 'ingredients' => $ingredients]);
    } else {
        echo json_encode(['success' => true, 'ingredients' => $ingredients]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
