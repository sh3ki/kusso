<?php
session_start();
include('includes/config.php');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Current Product Ingredients in Database</h2>";
    
    $stmt = $pdo->query("
        SELECT 
            pi.id, 
            pi.product_id, 
            p.product_name,
            pi.ingredient_id,
            i.name as ingredient_name,
            pi.quantity_required,
            pi.unit
        FROM product_ingredients pi
        JOIN products p ON pi.product_id = p.id
        JOIN ingredients i ON pi.ingredient_id = i.id
        ORDER BY p.product_name, i.name
    ");
    
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #c67c4e; color: white;'>
            <th>ID</th>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Ingredient ID</th>
            <th>Ingredient Name</th>
            <th>Quantity</th>
            <th>Unit</th>
          </tr>";
    
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($results) > 0) {
        foreach ($results as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['product_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['ingredient_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['ingredient_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['quantity_required']) . "</td>";
            echo "<td>" . htmlspecialchars($row['unit']) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='7' style='text-align: center; padding: 20px;'>No data found</td></tr>";
    }
    
    echo "</table>";
    
    echo "<hr>";
    echo "<h2>Check specific product ingredients</h2>";
    
    // Get all products
    $stmtProducts = $pdo->query("SELECT id, product_name FROM products LIMIT 10");
    $products = $stmtProducts->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($products as $product) {
        $stmtIngredients = $pdo->prepare("
            SELECT COUNT(*) as count FROM product_ingredients WHERE product_id = ?
        ");
        $stmtIngredients->execute([$product['id']]);
        $result = $stmtIngredients->fetch(PDO::FETCH_ASSOC);
        
        echo "<strong>" . htmlspecialchars($product['product_name']) . ":</strong> " . $result['count'] . " ingredients<br>";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
<hr>
<a href="inventory.php">Back to Inventory</a>
