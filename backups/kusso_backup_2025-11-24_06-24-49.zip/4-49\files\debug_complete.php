<?php
session_start();
include('includes/config.php');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Comprehensive Debug Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; }
        .debug-box { background: white; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 5px solid #c67c4e; }
        .success { border-left-color: #28a745; }
        .error { border-left-color: #dc3545; }
        pre { background: #f9f9f9; padding: 15px; border-radius: 3px; overflow-x: auto; max-height: 300px; }
        .code-value { background: #fffacd; padding: 2px 6px; border-radius: 3px; font-family: monospace; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔍 Debug: Multiple Ingredient Selection</h1>
    
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <div class="debug-box success">
        <h2>✅ POST Request Received</h2>
        
        <h3>Raw POST Data:</h3>
        <pre><?php print_r($_POST); ?></pre>
        
        <h3>Analysis:</h3>
        <?php
        $selectedIngredients = isset($_POST['selected_ingredients']) ? $_POST['selected_ingredients'] : [];
        $productId = $_POST['product_id'] ?? 'NOT SET';
        
        echo "<p><strong>Product ID:</strong> <span class='code-value'>" . htmlspecialchars($productId) . "</span></p>";
        echo "<p><strong>Type of selected_ingredients:</strong> <span class='code-value'>" . gettype($selectedIngredients) . "</span></p>";
        
        if (is_array($selectedIngredients)) {
            echo "<p><strong>Count of selected ingredients:</strong> <span class='code-value'>" . count($selectedIngredients) . "</span></p>";
            echo "<p><strong>Selected Ingredient IDs:</strong></p>";
            echo "<ul>";
            foreach ($selectedIngredients as $id) {
                echo "<li><span class='code-value'>" . htmlspecialchars($id) . "</span></li>";
            }
            echo "</ul>";
        } else {
            echo "<p class='text-danger'><strong>ERROR:</strong> selected_ingredients is not an array!</p>";
        }
        
        echo "<h3>Checking Quantity & Unit Fields:</h3>";
        echo "<table class='table table-bordered'>";
        echo "<tr><th>Ingredient ID</th><th>Quantity Key</th><th>Quantity Value</th><th>Unit Key</th><th>Unit Value</th></tr>";
        
        if (is_array($selectedIngredients)) {
            foreach ($selectedIngredients as $ingredientId) {
                $qtyKey = 'ingredient_quantity_' . $ingredientId;
                $unitKey = 'ingredient_unit_' . $ingredientId;
                
                $qtyValue = $_POST[$qtyKey] ?? '<span class="text-danger">NOT FOUND</span>';
                $unitValue = $_POST[$unitKey] ?? '<span class="text-danger">NOT FOUND</span>';
                
                echo "<tr>";
                echo "<td><span class='code-value'>$ingredientId</span></td>";
                echo "<td><span class='code-value'>$qtyKey</span></td>";
                echo "<td>" . htmlspecialchars($qtyValue) . "</td>";
                echo "<td><span class='code-value'>$unitKey</span></td>";
                echo "<td>" . htmlspecialchars($unitValue) . "</td>";
                echo "</tr>";
            }
        }
        echo "</table>";
        
        echo "<h3>All POST Keys:</h3>";
        echo "<p>";
        foreach ($_POST as $key => $value) {
            echo "<span class='code-value'>" . htmlspecialchars($key) . "</span> = <strong>" . htmlspecialchars($value) . "</strong><br>";
        }
        echo "</p>";
        ?>
    </div>
    <?php endif; ?>
    
    <div class="debug-box">
        <h2>📝 Test Form</h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label"><strong>Product:</strong></label>
                <select name="product_id" class="form-select" required>
                    <option value="">-- Select Product --</option>
                    <?php
                    try {
                        $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
                        $stmt = $pdo->query("SELECT id, product_name FROM products LIMIT 10");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['product_name']) . "</option>";
                        }
                    } catch (Exception $e) {
                        echo "<option>Error: " . htmlspecialchars($e->getMessage()) . "</option>";
                    }
                    ?>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label"><strong>Select Ingredients:</strong></label>
                <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                    <?php
                    try {
                        $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
                        $stmt = $pdo->query("SELECT id, name FROM ingredients LIMIT 10");
                        $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        foreach ($ingredients as $ingredient) {
                            $id = htmlspecialchars($ingredient['id']);
                            $name = htmlspecialchars($ingredient['name']);
                            echo "
                            <div class='row mb-3'>
                                <div class='col-md-3'>
                                    <input type='checkbox' name='selected_ingredients' value='$id' id='ing_$id' class='form-check-input'>
                                    <label for='ing_$id'>$name</label>
                                </div>
                                <div class='col-md-3'>
                                    <input type='number' name='ingredient_quantity_$id' class='form-control' placeholder='Qty' step='0.01'>
                                </div>
                                <div class='col-md-3'>
                                    <select name='ingredient_unit_$id' class='form-select'>
                                        <option value='grams'>grams</option>
                                        <option value='ml'>ml</option>
                                        <option value='pcs'>pcs</option>
                                    </select>
                                </div>
                            </div>";
                        }
                    } catch (Exception $e) {
                        echo "<p class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
                    }
                    ?>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Test POST Data</button>
        </form>
    </div>
    
    <div class="debug-box">
        <h2>🗄️ Current Database State</h2>
        <?php
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
            $stmt = $pdo->query("
                SELECT 
                    pi.id,
                    p.product_name,
                    i.name as ingredient_name,
                    pi.quantity_required,
                    pi.unit
                FROM product_ingredients pi
                JOIN products p ON pi.product_id = p.id
                JOIN ingredients i ON pi.ingredient_id = i.id
                LIMIT 20
            ");
            
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($rows) > 0) {
                echo "<table class='table table-bordered'>";
                echo "<tr><th>ID</th><th>Product</th><th>Ingredient</th><th>Qty</th><th>Unit</th></tr>";
                foreach ($rows as $row) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['ingredient_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['quantity_required']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['unit']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No data in product_ingredients table</p>";
            }
        } catch (Exception $e) {
            echo "<p class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
        ?>
    </div>
    
    <div class="mb-3">
        <a href="inventory.php" class="btn btn-secondary">Back to Inventory</a>
        <a href="manage_product_ingredients.php" class="btn btn-warning">Test Actual Form</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
