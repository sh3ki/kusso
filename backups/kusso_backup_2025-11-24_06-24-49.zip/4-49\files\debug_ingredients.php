<?php
session_start();
include('includes/config.php');

$pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug - Ingredients & Categories</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 20px; }
        .container { background: white; padding: 20px; border-radius: 5px; max-width: 1000px; margin: 0 auto; }
        .log { background: #f0f0f0; padding: 15px; border-radius: 3px; margin: 10px 0; border-left: 4px solid #ddd; }
        h2 { color: #333; border-bottom: 2px solid #c67c4e; padding-bottom: 10px; margin-top: 20px; }
        .success { border-left-color: #28a745; background: #f0fff4; }
        .error { border-left-color: #dc3545; background: #fff5f5; }
        .warning { border-left-color: #ffc107; background: #fffbf0; }
        .info { border-left-color: #17a2b8; background: #f0f8ff; }
        pre { background: #f9f9f9; padding: 10px; border-radius: 3px; overflow-x: auto; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        table th, table td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        table th { background: #c67c4e; color: white; }
        table tr:hover { background: #f5f5f5; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔍 Ingredient & Category Debug Information</h1>
    
    <h2>📋 ALL INGREDIENTS</h2>
    <div class="log info">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category ID</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $pdo->query("SELECT id, name, category_id, quantity, unit FROM ingredients ORDER BY id");
                $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($ingredients) > 0) {
                    foreach ($ingredients as $ing) {
                        echo "<tr>";
                        echo "<td>" . $ing['id'] . "</td>";
                        echo "<td>" . htmlspecialchars($ing['name']) . "</td>";
                        echo "<td>" . ($ing['category_id'] ?? '<span style="color: red;">NULL</span>') . "</td>";
                        echo "<td>" . $ing['quantity'] . "</td>";
                        echo "<td>" . htmlspecialchars($ing['unit']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' style='text-align: center; color: red;'>❌ NO INGREDIENTS FOUND</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <h2>🏷️ ALL CATEGORIES</h2>
    <div class="log info">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $pdo->query("SELECT id, name, type FROM categories ORDER BY id");
                $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($categories as $cat) {
                    echo "<tr>";
                    echo "<td>" . $cat['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($cat['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($cat['type']) . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <h2>🔗 CATEGORY_INGREDIENTS LINKS</h2>
    <div class="log info">
        <table>
            <thead>
                <tr>
                    <th>Link ID</th>
                    <th>Category</th>
                    <th>Ingredient</th>
                    <th>Qty Requirement</th>
                    <th>Unit</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $pdo->query("
                    SELECT ci.id, ci.category_id, ci.ingredient_id, ci.quantity_requirement, ci.unit,
                           c.name as category_name, i.name as ingredient_name
                    FROM category_ingredients ci
                    JOIN categories c ON ci.category_id = c.id
                    JOIN ingredients i ON ci.ingredient_id = i.id
                    ORDER BY c.id, i.name
                ");
                $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($links) > 0) {
                    foreach ($links as $link) {
                        echo "<tr>";
                        echo "<td>" . $link['id'] . "</td>";
                        echo "<td>" . htmlspecialchars($link['category_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($link['ingredient_name']) . "</td>";
                        echo "<td>" . $link['quantity_requirement'] . "</td>";
                        echo "<td>" . htmlspecialchars($link['unit']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' style='text-align: center; color: orange;'>⚠️ NO LINKS YET - Add some!</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <h2>⚙️ TEST QUERY - Available Ingredients for Each Category</h2>
    <div class="log warning">
        <?php
        foreach ($categories as $cat) {
            echo "<h3>" . htmlspecialchars($cat['name']) . " (ID: " . $cat['id'] . ")</h3>";
            
            $test_stmt = $pdo->prepare("
                SELECT i.* FROM ingredients i
                WHERE i.category_id = :category_id
                AND i.id NOT IN (
                    SELECT ingredient_id FROM category_ingredients 
                    WHERE category_id = :category_id
                )
                ORDER BY i.name
            ");
            $test_stmt->execute([':category_id' => $cat['id']]);
            $available = $test_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($available) > 0) {
                echo "<p style='color: green;'>✓ Found " . count($available) . " available ingredients:</p>";
                echo "<ul>";
                foreach ($available as $ing) {
                    echo "<li>" . htmlspecialchars($ing['name']) . " (ID: " . $ing['id'] . ")</li>";
                }
                echo "</ul>";
            } else {
                echo "<p style='color: orange;'>⚠️ No available ingredients (all linked or none exist)</p>";
            }
        }
        ?>
    </div>
    
    <h2>Test Form</h2>
    <form method="POST">
        <div class="log">
            <label>
                <input type="checkbox" name="selected_ingredients" value="1"> Ingredient 1
                Qty: <input type="number" name="ingredient_quantity_1" value="10" style="width: 80px;">
                Unit: <select name="ingredient_unit_1">
                    <option>grams</option>
                    <option>ml</option>
                    <option>pcs</option>
                </select>
            </label><br><br>
            
            <label>
                <input type="checkbox" name="selected_ingredients" value="2"> Ingredient 2
                Qty: <input type="number" name="ingredient_quantity_2" value="50" style="width: 80px;">
                Unit: <select name="ingredient_unit_2">
                    <option>ml</option>
                    <option>grams</option>
                    <option>pcs</option>
                </select>
            </label><br><br>
            
            <label>
                <input type="checkbox" name="selected_ingredients" value="3"> Ingredient 3
                Qty: <input type="number" name="ingredient_quantity_3" value="5" style="width: 80px;">
                Unit: <select name="ingredient_unit_3">
                    <option>pcs</option>
                    <option>grams</option>
                    <option>ml</option>
                </select>
            </label><br><br>
        </div>
        
        <input type="hidden" name="product_id" value="1">
        <button type="submit" name="link_ingredient_btn">Submit Test Form</button>
    </form>
    
    <h2>Database Check</h2>
    <div class="log info">
        <?php
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $stmt = $pdo->query("SELECT * FROM product_ingredients LIMIT 10");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "Recent product_ingredients records:\n";
            echo "<pre>";
            print_r($rows);
            echo "</pre>";
        } catch (Exception $e) {
            echo "<div class='log error'>Error: " . $e->getMessage() . "</div>";
        }
        ?>
    </div>
    
    <button onclick="window.location.href='inventory.php'">Back to Inventory</button>
</div>
</body>
</html>
