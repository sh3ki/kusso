<?php
header('Content-Type: application/json');
include('includes/config.php');

$threshold = 100; // You can adjust this value

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->prepare("SELECT name, quantity, unit FROM ingredients WHERE quantity <= :threshold");
    $stmt->execute(['threshold' => $threshold]);
    $lowStock = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'low_stock' => $lowStock]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
