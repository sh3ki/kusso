<?php
echo ini_get('error_log');
