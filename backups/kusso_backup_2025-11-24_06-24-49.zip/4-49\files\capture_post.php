<?php
session_start();

// Create a log file to capture POST data
$logFile = 'ingredient_post_log.txt';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['link_ingredient_btn'])) {
    $logData = "=== POST REQUEST AT " . date('Y-m-d H:i:s') . " ===\n";
    $logData .= "Product ID: " . ($_POST['product_id'] ?? 'NOT SET') . "\n";
    $logData .= "Selected Ingredients: " . print_r($_POST['selected_ingredients'] ?? [], true) . "\n";
    $logData .= "\nAll POST keys:\n";
    
    foreach ($_POST as $key => $value) {
        $logData .= "  $key = $value\n";
    }
    
    $logData .= "\n--- ANALYSIS ---\n";
    
    $selectedIngredients = isset($_POST['selected_ingredients']) ? $_POST['selected_ingredients'] : [];
    if (is_array($selectedIngredients)) {
        $logData .= "Selected count: " . count($selectedIngredients) . "\n";
        foreach ($selectedIngredients as $ingredientId) {
            $qtyKey = 'ingredient_quantity_' . $ingredientId;
            $unitKey = 'ingredient_unit_' . $ingredientId;
            $qty = $_POST[$qtyKey] ?? 'MISSING';
            $unit = $_POST[$unitKey] ?? 'MISSING';
            $logData .= "  Ingredient $ingredientId: qty=$qty, unit=$unit\n";
        }
    } else {
        $logData .= "ERROR: selected_ingredients is not an array, it's a " . gettype($selectedIngredients) . "\n";
    }
    
    $logData .= "\n\n";
    
    file_put_contents($logFile, $logData, FILE_APPEND);
    
    echo "<h1>POST Data Captured!</h1>";
    echo "<p>Data has been logged to <code>$logFile</code></p>";
    echo "<pre>" . htmlspecialchars($logData) . "</pre>";
    echo "<a href='capture_post.php'>Check log again</a> | <a href='inventory.php'>Back to inventory</a>";
} else {
    echo "<h1>POST Capture Handler</h1>";
    echo "<p>This file captures POST requests from the ingredient linking form.</p>";
    
    if (file_exists($logFile)) {
        echo "<h2>Latest Requests:</h2>";
        echo "<pre>" . htmlspecialchars(file_get_contents($logFile)) . "</pre>";
        echo "<a href='capture_post.php?clear=1'>Clear log</a>";
    } else {
        echo "<p>No logs yet. Submit the ingredient form to see data.</p>";
    }
}

if (isset($_GET['clear'])) {
    file_put_contents($logFile, '');
    header("Refresh: 0");
}
?>
