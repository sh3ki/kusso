<?php
session_start();
include('../kusso/includes/header.php');
include('../kusso/includes/navbar.php');
include('../kusso/includes/config.php');
include('../kusso/includes/auth.php');

// Allow only admin and cashier
checkAccess(['admin']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>KUSSO-Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="mt-4">Inventory</h1>
                <div class="btn-group mt-4" role="group">
                    <a href="assign_ingredients_to_categories.php" class="btn" style="color: #ffffff; background-color:#6c757d; border:none;" title="Assign ingredients to categories first">
                        <i class="fas fa-tags me-1"></i> Assign to Categories
                    </a>
                    <a href="manage_category_ingredients.php" class="btn" style="color: #ffffff; background-color:#c67c4e; border:none;">
                        <i class="fas fa-layer-group me-1"></i> Manage Category Ingredients
                    </a>
                </div>
            </div>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success_message'];
                        unset($_SESSION['success_message']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <?php 
                        echo $_SESSION['error_message'];
                        unset($_SESSION['error_message']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Display low stock ingredients alert at the very top -->
            <?php
            try {
                $threshold = 100;
                $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $pdo->prepare("SELECT name, quantity, unit FROM ingredients WHERE quantity <= :threshold");
                $stmt->execute(['threshold' => $threshold]);
                $lowStock = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (count($lowStock) > 0) {
                    echo '<div class="alert alert-danger mt-4"><b>Low Stock Ingredients:</b><ul style="margin-bottom:0;">';
                    foreach ($lowStock as $item) {
                        echo '<li><b>' . htmlspecialchars($item['name']) . '</b>: ' . htmlspecialchars($item['quantity']) . ' ' . htmlspecialchars($item['unit']) . '</li>';
                    }
                    echo '</ul></div>';
                }
            } catch (PDOException $e) {
                echo '<div class="alert alert-danger">Error fetching low stock: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
            ?>


            <!-- Add Ingredient Modal -->
            <div class="modal fade" id="addIngredientModal" tabindex="-1" aria-labelledby="addIngredientModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="manage_inventory.php" method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addIngredientModalLabel">Add Ingredient</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Ingredient Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="quantity" class="form-label">Quantity</label>
                                    <input type="number" step="0.01" class="form-control" id="quantity" name="quantity" required>
                                </div>
                                <div class="mb-3">
                                    <label for="unit" class="form-label">Unit</label>
                                    <input type="text" class="form-control" id="unit" name="unit" placeholder="e.g., kg, liters" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="add_ingredient_btn" class="btn" style="color: #ffffff; background-color:#c67c4e; border:none;">Add Ingredient</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Ingredients Table -->
            <div class="card shadow mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-table me-1"></i> Manage Ingredients</span>

                     <!-- Add Ingredient Button -->
                      <div class="d-flex">
                          <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#addIngredientModal" title="Add a new ingredient" style="color: #ffffff; background-color:#c67c4e; border:none;">
                              <i class="fa-solid fa-plus"></i> Add Ingredient
                          </button>
                      </div>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple" class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Unit</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            try {
                                $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                $stmt = $pdo->query("SELECT * FROM ingredients");
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    echo "<tr>
                                        <td>" . htmlspecialchars($row['name']) . "</td>
                                        <td>" . htmlspecialchars($row['quantity']) . "</td>
                                        <td>" . htmlspecialchars($row['unit']) . "</td>
                                        <td>
                                            <!-- Edit Button -->
                                            <button type='button' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#editIngredientModal" . htmlspecialchars($row['id']) . "'>
                                                <i class='fa fa-edit'></i>
                                            </button>

                                            <!-- Delete Button -->
                                            <form action='manage_inventory.php' method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure you want to delete this ingredient?\");'>
                                                <input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>
                                                <button type='submit' name='delete_ingredient_btn' class='btn btn-danger'>
                                                    <i class='fa fa-trash'></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";

                                    // Edit Ingredient Modal
                                    echo "
                                    <div class='modal fade' id='editIngredientModal" . htmlspecialchars($row['id']) . "' tabindex='-1' aria-labelledby='editIngredientModalLabel" . htmlspecialchars($row['id']) . "' aria-hidden='true'>
                                        <div class='modal-dialog'>
                                            <div class='modal-content'>
                                                <form action='manage_inventory.php' method='POST'>
                                                    <div class='modal-header'>
                                                        <h5 class='modal-title' id='editIngredientModalLabel" . htmlspecialchars($row['id']) . "'>Edit Ingredient</h5>
                                                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                    </div>
                                                    <div class='modal-body'>
                                                        <input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>
                                                        <div class='mb-3'>
                                                            <label for='name" . htmlspecialchars($row['id']) . "' class='form-label'>Ingredient Name</label>
                                                            <input type='text' class='form-control' id='name" . htmlspecialchars($row['id']) . "' name='name' value='" . htmlspecialchars($row['name']) . "' required>
                                                        </div>
                                                        <div class='mb-3'>
                                                            <label for='quantity" . htmlspecialchars($row['id']) . "' class='form-label'>Quantity</label>
                                                            <input type='number' step='0.01' class='form-control' id='quantity" . htmlspecialchars($row['id']) . "' name='quantity' value='" . htmlspecialchars($row['quantity']) . "' required>
                                                        </div>
                                                        <div class='mb-3'>
                                                            <label for='unit" . htmlspecialchars($row['id']) . "' class='form-label'>Unit</label>
                                                            <input type='text' class='form-control' id='unit" . htmlspecialchars($row['id']) . "' name='unit' value='" . htmlspecialchars($row['unit']) . "' required>
                                                        </div>
                                                    </div>
                                                    <div class='modal-footer'>
                                                        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                                                        <button type='submit' name='edit_ingredient_btn' class='btn' style='color: #ffffff; background-color: #c67c4e; border: none;'>Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>";
                                }
                            } catch (PDOException $e) {
                                echo "<tr><td colspan='4'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>


        <!-- Linked Ingredients Table -->
        <div class="card shadow mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-link me-1"></i> Link Ingredients to Products</span>

                 <!-- Link Ingredient Button -->
                 <div class="d-flex">
                    <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#linkIngredientModal" title="Link an ingredient to a product" style="color: #ffffff; background-color:#c67c4e; border:none;">
                        <i class="fa-solid fa-link"></i> Link Ingredient
                    </button>
                </div>
            </div>


            <div class="card-body">
                <table id="linkedIngredientsTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Product Name</th>
                            <th scope="col">Ingredient Name</th>
                            <th scope="col">Quantity Required</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php
                            try {
                                // First, check if unit column exists and add it if it doesn't
                                $checkCol = $pdo->query("SHOW COLUMNS FROM product_ingredients LIKE 'unit'");
                                if ($checkCol->rowCount() == 0) {
                                    $pdo->exec("ALTER TABLE product_ingredients ADD COLUMN unit VARCHAR(50) DEFAULT 'grams' AFTER quantity_required");
                                }
                                
                                // Updated query to include product options and unit
                                $stmt = $pdo->query("
                                    SELECT 
                                        pi.id AS link_id, 
                                        p.product_name AS product_name, 
                                        p.options AS product_option, 
                                        i.name AS ingredient_name, 
                                        pi.quantity_required,
                                        COALESCE(pi.unit, 'grams') AS unit
                                    FROM product_ingredients pi
                                    JOIN products p ON pi.product_id = p.id
                                    JOIN ingredients i ON pi.ingredient_id = i.id
                                ");
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    // Combine product name and option
                                    $productDisplay = htmlspecialchars($row['product_name']);
                                    if (!empty($row['product_option'])) {
                                        $productDisplay .= " (" . htmlspecialchars($row['product_option']) . ")";
                                    }
                                    echo "<tr>
                                        <td>" . $productDisplay . "</td>
                                        <td>" . htmlspecialchars($row['ingredient_name']) . "</td>
                                        <td>" . htmlspecialchars($row['quantity_required']) . "</td>
                                        <td>" . htmlspecialchars($row['unit']) . "</td>
                                        <td>
                                            <form action='manage_product_ingredients.php' method='POST' style='display:inline;' onsubmit='return confirm(\"Are you sure you want to unlink this ingredient?\");'>
                                                <input type='hidden' name='id' value='" . htmlspecialchars($row['link_id']) . "'>
                                                <button type='submit' name='unlink_ingredient_btn' class='btn btn-danger'>
                                                    <i class='fa fa-unlink'></i> Unlink
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                                }
                            } catch (PDOException $e) {
                                echo "<tr><td colspan='5'>Error: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
                            }
                            ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Link Ingredient Modal -->
        <div class="modal fade" id="linkIngredientModal" tabindex="-1" aria-labelledby="linkIngredientModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="manage_product_ingredients.php" method="POST">
                        <div class="modal-header">
                            <h5 class="modal-title" id="linkIngredientModalLabel">Link Ingredients to Product</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="product_id" class="form-label">Product</label>
                                <select class="form-control" id="product_id" name="product_id" required>
                                    <option value="">Select a product...</option>
                                    <?php
                                    try {
                                        $stmt = $pdo->query("SELECT id, product_name, options FROM products");
                                        while ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            $optionText = !empty($product['options']) ? " (" . htmlspecialchars($product['options']) . ")" : "";
                                            echo "<option value='" . htmlspecialchars($product['id']) . "'>" . htmlspecialchars($product['product_name']) . $optionText . "</option>";
                                        }
                                    } catch (PDOException $e) {
                                        echo "<option>Error: " . htmlspecialchars($e->getMessage()) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            
                            <hr>
                            <label class="form-label"><strong>Select Ingredients</strong></label>
                            <div class="mb-3" style="max-height: 400px; overflow-y: auto; border: 1px solid #dee2e6; padding: 15px; border-radius: 0.375rem;">
                                <?php
                                try {
                                    $stmt = $pdo->query("SELECT id, name FROM ingredients ORDER BY name");
                                    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if (count($ingredients) > 0) {
                                        foreach ($ingredients as $ingredient) {
                                            $ingredientId = htmlspecialchars($ingredient['id']);
                                            $ingredientName = htmlspecialchars($ingredient['name']);
                                            echo "
                                            <div class='row mb-3 align-items-end'>
                                                <div class='col-md-1'>
                                                    <input type='checkbox' class='form-check-input ingredient-checkbox' name='selected_ingredients[]' value='" . $ingredientId . "' id='ingredient_" . $ingredientId . "'>
                                                </div>
                                                <div class='col-md-5'>
                                                    <label for='ingredient_" . $ingredientId . "' class='form-check-label'>" . $ingredientName . "</label>
                                                </div>
                                                <div class='col-md-3'>
                                                    <input type='number' step='0.01' class='form-control ingredient-quantity' name='ingredient_quantity_" . $ingredientId . "' placeholder='Qty' min='0'>
                                                </div>
                                                <div class='col-md-3'>
                                                    <select class='form-select ingredient-unit' name='ingredient_unit_" . $ingredientId . "'>
                                                        <option value='grams'>grams</option>
                                                        <option value='ml'>ml</option>
                                                        <option value='pcs'>pcs</option>
                                                    </select>
                                                </div>
                                            </div>";
                                        }
                                    } else {
                                        echo "<p class='text-muted'>No ingredients available. Please add ingredients first.</p>";
                                    }
                                } catch (PDOException $e) {
                                    echo "<p class='text-danger'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="link_ingredient_btn" class="btn" style="color: #ffffff; background-color: #c67c4e; border: none;">Link Ingredients</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const linkIngredientModal = document.getElementById('linkIngredientModal');
            
            // Reset form ONLY when modal is shown (before user interacts)
            if (linkIngredientModal) {
                linkIngredientModal.addEventListener('show.bs.modal', function() {
                    // Reset all checkboxes
                    document.querySelectorAll('.ingredient-checkbox').forEach(checkbox => {
                        checkbox.checked = false;
                    });
                    
                    // Clear all quantity inputs
                    document.querySelectorAll('.ingredient-quantity').forEach(input => {
                        input.value = '';
                    });
                    
                    // Reset all unit selects to first option
                    document.querySelectorAll('.ingredient-unit').forEach(select => {
                        select.selectedIndex = 0;
                    });
                    
                    // Reset product select
                    const productSelect = document.getElementById('product_id');
                    if (productSelect) {
                        productSelect.selectedIndex = 0;
                    }
                });
            }
            
            const checkboxes = document.querySelectorAll('.ingredient-checkbox');
            
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const ingredientId = this.value;
                    const quantityInput = document.querySelector('input[name="ingredient_quantity_' + ingredientId + '"]');
                    const unitSelect = document.querySelector('select[name="ingredient_unit_' + ingredientId + '"]');
                    
                    if (this.checked) {
                        quantityInput.focus();
                    } else {
                        quantityInput.value = '';
                    }
                });
            });
        });
        </script>

    
            </main>

        <?php
        include('../kusso/includes/footer.php');
        include('../kusso/includes/scripts.php');
        ?>
</body>
</html>