<?php
include('includes/config.php');

try {
    $pdo = new PDO("mysql:host=localhost;dbname=kusso", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Check if unit column exists
    $stmt = $pdo->query("DESCRIBE product_ingredients");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasUnit = false;
    foreach ($columns as $col) {
        if ($col['Field'] === 'unit') {
            $hasUnit = true;
            break;
        }
    }
    
    if (!$hasUnit) {
        // Add unit column
        $pdo->exec("ALTER TABLE product_ingredients ADD COLUMN unit VARCHAR(50) DEFAULT 'grams' AFTER quantity_required");
        echo "Unit column added successfully!";
    } else {
        echo "Unit column already exists!";
    }
    
    echo "<br><pre>";
    print_r($columns);
    echo "</pre>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
