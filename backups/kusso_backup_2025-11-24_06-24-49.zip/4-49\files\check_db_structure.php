<?php
include 'includes/config.php';

$pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);

echo "🔍 Checking database structure...\n\n";

// Check if ingredients table exists and show its structure
echo "=== INGREDIENTS TABLE ===\n";
$stmt = $pdo->query("DESCRIBE ingredients");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo $row['Field'] . " | " . $row['Type'] . " | " . ($row['Key'] ?? '') . "\n";
}

// Check foreign key constraints
echo "\n=== FOREIGN KEY CONSTRAINTS ===\n";
$stmt = $pdo->query("SELECT CONSTRAINT_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = 'ingredients'");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Constraint: " . $row['CONSTRAINT_NAME'] . " | Column: " . $row['COLUMN_NAME'] . " | References: " . $row['REFERENCED_TABLE_NAME'] . "\n";
}

// Check what tables exist
echo "\n=== EXISTING TABLES ===\n";
$stmt = $pdo->query("SHOW TABLES");
while($row = $stmt->fetch(PDO::FETCH_NUM)) {
    echo "  • " . $row[0] . "\n";
}
?>
